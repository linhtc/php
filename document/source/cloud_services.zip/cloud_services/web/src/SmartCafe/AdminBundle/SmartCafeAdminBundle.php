<?php

namespace SmartCafe\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SmartCafeAdminBundle extends Bundle
{
}
