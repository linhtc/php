/** Files */
Gcs+xxx+.orm.xml 
	==> Auto generated files.
User.orm.xml
BaseUser.orm.xml
Group.orm.xml
Role.orm.xml
Temp.orm.xml
UserRepository.orm.xml
UserTemp.orm.xml
	==> Handmade files.

Author: Viet Hung