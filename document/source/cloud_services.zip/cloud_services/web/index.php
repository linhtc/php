<?php

	print_r(ptpinfo()); exit;
