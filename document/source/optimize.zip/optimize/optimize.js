Optimize = {
	initFormControl: function(){
		$(".search").each(function(){
			var name = $(this).attr('id');
			var val = $(this).val();
			var optsl = $(this).attr('optsl');
			if(optsl != undefined){
				var optslClick = $(this).attr('optslClick');
				var configSelect = {};
				configSelect[optsl] = true;
				configSelect['filter'] = true;
				configSelect['placeholder'] = $(this).attr('placeholder');
				if(optslClick != undefined){
					configSelect['onClick'] = eval(optslClick);
				}
				$('#'+name).multipleSelect(configSelect);
				$('#'+name).multipleSelect('uncheckAll');
				if(configSelect.onClick != undefined){
					$( "input[name*='selectAll"+name+"']" ).click(function(){ 
						var func = eval(optslClick); if(typeof func == 'function'){ func(); }
					});
				}
				$('#'+name).parent().find('.option').css({'padding-left': '20px'});
			}
		});
		$('.multiple').css({'width': '100%'});
		//$('.option').css({'padding-left': '20px'});
		return false;
	},
	getFormControlValue: function(){
		var search = {};
		$(".search").each(function(){
			var name = $(this).attr('id');
			var val = $(this).val();
			var optsl = $(this).attr('optsl');
			var optslCheckAllForSearch = $(this).attr('optslCheckAllForSearch');
			if(optsl != undefined){
				val = $('#'+name).multipleSelect('getSelects');
				if(val == "''" || val == '' || typeof val == 'object'){
					if(optslCheckAllForSearch != undefined){
						$('#'+name).multipleSelect('checkAll');
						val = $('#'+name).multipleSelect('getSelects');
						$('#'+name).multipleSelect('uncheckAll');
					}
				}				
				if(val == "''" || val == '' || typeof val == 'object'){
					val = '';
				}
			}
			if(name != undefined){
				search[name] = val;
			}
		});
		var searchs = JSON.stringify(search);
		return searchs;
	},
	getDataWithAjax: function(page){
		var searchs = Optimize.getFormControlValue();
		var el = jQuery("#"+gridView);
		var elFS = jQuery("#"+formView);
		App.blockUI({target: el, iconOnly: true});
        App.blockUI({target: elFS, iconOnly: false});
		$.ajax({
			type: "POST",
			url: 'getList',
			data: {
				page:page, searchs:searchs
			},
			success: function(data) {
				$("#"+gridView).html(data);
				App.initAjax();
                App.unblockUI(el);
                App.unblockUI(elFS);
				var checkEdit = $('#edit').attr('id');
				if(checkEdit == undefined){
					return false;
				}
				$("#"+gridView+" tr").css({'cursor':'pointer'});
				$('.delete').each(function(){
					$(this).click(function(){
						var idDel = $(this).attr('idDel');
						$.msgBox({
							title: 'Message',
							content: 'Are you sure you want to delete this?',
							type: "alert",
							buttons: [{ value: "Yes"},{ value: "No"}],
							success: function (result) {
								if(result == 'Yes'){
									Optimize.deleteDataWithAjax(idDel);
								}
							}
						}); 
					});
				});
				$("#"+gridView+" tr td").live('click',function(){
					if($(this).is(":first-child") || $(this).is(":last-child")){
						console.log('--prevent click--');
						return false; 
					}
					var objTr = $(this).parent().find('.edit');
					var id = objTr.attr('id');
					var datas = objTr.attr('datas');
					var p = Optimize.parseJson(datas);
					for (var key in p) {
						if (p.hasOwnProperty(key)) {
							// alert(key + " -> " + p[key]);
							// $('#'+key).val(p[key]);
							var valTmp = p[key];
							var objTmp = $('#'+key);
							var optsl = objTmp.attr('optsl');
							var opttimepicker = objTmp.attr('timepicker');
							if(optsl != undefined){
								if(valTmp != ''){
									$('#'+key).multipleSelect('setSelects', valTmp.split(','));
								}
								var optslClick = objTmp.attr('optslClick');
								if(optslClick != undefined){
									var func = eval(optslClick);
									if(typeof func == 'function'){
										func();
									}
								}
							} else if(opttimepicker != undefined){
								$('#'+key).timepicker('setTime', valTmp);
							} else {
								$('#'+key).val(valTmp);
							}
						}
					}
					$('body, html').animate({scrollTop:0},800);
				});
				$("#"+gridView+" tr td").css({'text-align': 'center'});
				$("#"+gridView+" tr th").css({'text-align': 'center'});
				$('#checkAll').live('click', function(){
					if($(this).attr("checked") == 'checked' || $(this).attr("checked") == true){
						$("#"+gridView).find('input.check').attr("checked","checked");
					} else{
						$("#"+gridView).find('input.check').removeAttr("checked");
					}
				});
			},
			error: function(){
				App.initAjax();
                App.unblockUI(el);
                App.unblockUI(elFS);
			}
		});
		return false;
	},
	deleteDataWithAjax: function(idList){
		var el = jQuery("#"+gridView);
		var elFS = jQuery("#"+formView);
		App.blockUI({target: el, iconOnly: true});
        App.blockUI({target: elFS, iconOnly: false});
		$.ajax({
			type:"POST",
			url:"delete",
			data:{idList:idList},
			success:function(data){
				App.unblockUI($('.ccontent'));
				App.initAjax();
                App.unblockUI(el);
                App.unblockUI(elFS);
				$.msgBox({
					title: 'Message',
					content: data,
					type: "alert",
					buttons: [{ value: "OK"}],
					success: function (result) {
						if(data.indexOf('success') >= 0){
							Optimize.resetFormControl();
							Optimize.getDataWithAjax(1);
						}
					}
				}); 
			}  
		});
	},
	saveDataWithAjax: function(id, dataPost){
		var el = jQuery("#"+gridView);
		var elFS = jQuery("#"+formView);
		App.blockUI({target: el, iconOnly: true});
        App.blockUI({target: elFS, iconOnly: false});
		$.ajax({
			type: "POST",
			url: 'save',
			data: {
				id:id, dataPost:dataPost
			},
			success: function(data) {
				App.initAjax();
                App.unblockUI(el);
                App.unblockUI(elFS);
				$.msgBox({
					title: 'Message',
					content: data,
					type: "alert",
					buttons: [{ value: "OK"}],
					success: function (result) {
						if(data.indexOf('success') >= 0){
							Optimize.resetFormControl();
							Optimize.getDataWithAjax(1);
						}
					}
				}); 
			},
			error: function(){
				App.initAjax();
                App.unblockUI(el);
                App.unblockUI(elFS);
			}
		});
	},
	getIdListForDelete: function(){
		var idList = '';
		$('#'+gridView+' .check:checked').each(function(){
			id = $(this).val();
			idList += (idList == '' ? '' : ',') + id;
		});
		return idList;
	},
	resetFormControl: function(){
		$(".search").each(function(){
			var name = $(this).attr('id');
			var val = $(this).val();
			var optsl = $(this).attr('optsl');
			var opttimepicker = $(this).attr('timepicker');
			if(optsl != undefined){
				$('#'+name).multipleSelect('uncheckAll');
				var optslClick = $(this).attr('optslClick');
				if(optslClick != undefined){
					var func = eval(optslClick);
					if(typeof func == 'function'){
						func();
					}
				}
			} else if(opttimepicker != undefined){
				$('#'+name).timepicker('setTime', '0:00:00');
				$('#'+name).val('0:00:00');
			} else {
				$('#'+name).val('');
			}
		});
		$('#id_edit').val('');
	},
	checkEmptyFormControl: function(){
		var msg = '';
		var search = {};
		$(".search").each(function(){
			var name = $(this).attr('id');
			var val = $(this).val();
			var optsl = $(this).attr('optsl');
			var msgEmpty = $(this).attr('msgempty');
			var msgChooseOne = $(this).attr('msgchooseone');
			var optslCheckAllForSearch = $(this).attr('optslCheckAllForSearch');
			if(msgEmpty != undefined){
				if(optsl != undefined){
					val = $('#'+name).multipleSelect('getSelects');
					if(val == "''" || val == '' || typeof val == 'object'){
						msg = msgEmpty; return false;
					}
					if(msgChooseOne != undefined){
						var checkOne = val.split(',');
						if(checkOne.length > 1){
							msg = msgChooseOne; return false;
						}
					}
				} else if(val == ''){
					msg = msgEmpty; return false;
				}
			}
			//for return search
			if(optsl != undefined){
				val = $('#'+name).multipleSelect('getSelects');
				if(val == "''" || val == '' || typeof val == 'object'){
					if(optslCheckAllForSearch != undefined){
						$('#'+name).multipleSelect('checkAll');
						val = $('#'+name).multipleSelect('getSelects');
						$('#'+name).multipleSelect('uncheckAll');
					}
				}				
				if(val == "''" || val == '' || typeof val == 'object'){
					val = '';
				}
			}
			if(name != undefined){
				search[name] = val;
			}
		});
		if(msg != ''){
			return msg;
		}
		return search;
	},
	parseJson: function (strParse){
		var objectParser = {};
		try{
			objectParser = JSON.parse(strParse);
		} catch(exx){
			console.log(exx);
			objectParser = {};
		}
		return objectParser;
	}
}