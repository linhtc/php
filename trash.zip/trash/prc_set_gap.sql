DELIMITER $$

CREATE DEFINER=`apilabs`@`%` PROCEDURE `prc_set_gap`()
BEGIN
	if time(now()) > time('22:00:00') then
		update campaign_gifts g set g.gap = 9999 where g.public_date = date_format(now(), '%Y%m%d');
		update campaign_gifts g set g.gap = 9999 where g.public_date = date_format(now() + INTERVAL 1 DAY, '%Y%m%d');
	else 
		update campaign_gifts g set g.gap = 12 where g.public_date = date_format(now(), '%Y%m%d');
	end if;
END