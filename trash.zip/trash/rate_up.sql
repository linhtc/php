update models as m 
inner join (
	select rs3.*
	from(
		select rs2.brand, rs2.model, cast(sum(((rs2.total / p.child) * (p.percent / 100))) as decimal(12, 1)) rates
		from(
			select rs.brand, rs.model, sum(rs.rate) total, rs.parent
			from(
				select r.brand, r.model, r.rate, (select p.parent from points p where p.title = r.feature and p.deleted = 0) parent
				from rates r 
				where r.feature in (select bd.title from points bd where bd.parent <> 0 and bd.deleted = 0)
			) rs
			group by rs.brand, rs.model, rs.parent
		) rs2
		inner join points p on p.id = rs2.parent
		group by rs2.brand, rs2.model
	) rs3
) as rs4 on m.brand = rs4.brand and m.model = rs4.model
set m.rate = rs4.rates
where m.deleted = 0 and m.id > 0;