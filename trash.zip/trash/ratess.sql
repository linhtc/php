select cast(sum(((rs2.total / p.child) * (p.percent / 100))) as decimal(12, 1)) rates,
	rs2.total, p.child, p.percent
from(
	select sum(rs.rate) total, rs.parent
	from(
		select r.rate, (select p.parent from points p where p.title = r.feature) parent
		from rates r 
		where (r.brand, r.model) in (('Mobiistar', 'Zumbo J 2018')) 
			and r.feature in (select bd.title from points bd where bd.parent <> 0 and bd.deleted = 0)
	) rs
	group by rs.parent
) rs2
inner join points p on p.id = rs2.parent
group by p.id