ALTER TABLE `primex2k17`.`gift_vouchers` 
CHANGE COLUMN `campaign_id` `campaign` BIGINT(20) NULL DEFAULT '0' AFTER `user_ip`,
CHANGE COLUMN `distributor_id` `distributor` BIGINT(20) NULL DEFAULT '0' AFTER `campaign`,
CHANGE COLUMN `voucher_group` `voucher_group` INT(11) NULL COMMENT '1: 200.000, 2: 300.000, 3: 500.00' ,
ADD COLUMN `model_name` VARCHAR(255) NULL AFTER `model`;
