
update social_users u set u.is_spam = 0, u.is_lucky = 0 where u.social_id = '' and u.id > 0;
delete from playgame_luckies where id > 0 and social_id = '';
delete from winners where id > 0 and social_id = '';
delete from blacklist where id > 0 and ip4 = '';