

--
-- Table structure for table `gift_list`
--

DROP TABLE IF EXISTS `gift_list`;
CREATE TABLE `gift_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `campaign` bigint(20) DEFAULT '0',
  `gift_id` int(11) DEFAULT '0',
  `gift_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_name` (`id`,`gift_name`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gift_list`
--

INSERT INTO `gift_list` VALUES (1,9,1,'Điện thoại Prime X 2017'),(2,9,2,'Điện thoại Prime X1'),(3,9,3,'Sạc dự phòng 5000mAh'),(4,9,4,'Balo thời trang'),(5,9,5,'VOUCHER ƯU ĐÃI 200.000 VNĐ'),(6,9,6,'VOUCHER ƯU ĐÃI 300.000 VNĐ'),(7,9,7,'VOUCHER ƯU ĐÃI 500.000 VNĐ'),(8,9,8,'Thẻ cào trị giá 50.000 VNĐ'),(9,9,9,'Thẻ cào trị giá 20.000 VNĐ'),(10,9,10,'Thẻ cào trị giá 10.000 VNĐ'),(11,11,1,'Điện thoại Prime X1'),(12,11,2,'Điện thoại Zumbo J 2017'),(13,11,3,'Điện thoại B223'),(14,11,4,'Sạc dự phòng'),(15,11,5,'Balo'),(16,11,6,'Gậy selfie'),(17,11,7,'Thẻ cào 200.000 VNĐ'),(18,11,8,'Thẻ cào 100.000 VNĐ'),(19,11,9,'Thẻ cào 50.000 VNĐ'),(20,11,10,'Thẻ cào 20.000 VNĐ'),(21,11,11,'Thẻ cào 10.000 VNĐ'),(22,11,12,'VOUCHER PRIME X1 giảm 20%'),(23,11,13,'VOUCHER PRIME X1 giảm 25%'),(24,11,14,'VOUCHER PRIME X1 giảm 30%'),(25,11,15,'VOUCHER PRIME X1 giảm 50%'),(26,11,16,'VOUCHER ZUMBO J 2017 giảm 20%'),(27,11,17,'VOUCHER ZUMBO J 2017 giảm 25%'),(28,11,18,'VOUCHER ZUMBO J 2017 giảm 30%'),(29,11,19,'VOUCHER ZUMBO J 2017 giảm 50%');
