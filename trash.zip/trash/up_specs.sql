update overviews o set o.brand = 'Huawei', o.model = 'G9 Lite L31 Also Known as G9' where o.brand = ': Huawei';
update features o set o.brand = 'Huawei', o.model = 'G9 Lite L31 Also Known as G9' where o.brand = ': Huawei';
update rates o set o.brand = 'Huawei', o.model = 'G9 Lite L31 Also Known as G9' where o.brand = ': Huawei';
update models o set o.brand = 'Huawei', o.model = 'G9 Lite L31 Also Known as G9' where o.brand = ': Huawei';