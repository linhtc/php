
-- MySQL dump 10.13  Distrib 5.6.35, for Linux (x86_64)
--
-- Host: localhost    Database: retail_mode
-- ------------------------------------------------------
-- Server version	5.6.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `configurations`
--

DROP TABLE IF EXISTS `configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configurations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `ip4` varchar(255) DEFAULT NULL,
  `campaign` bigint(20) DEFAULT '0',
  `distributor` bigint(20) DEFAULT '0',
  `apply_key` varchar(255) DEFAULT NULL COMMENT 'config key, vi du registered_extra = 100',
  `apply_value` varchar(100) DEFAULT NULL COMMENT 'config value, vi du registered_extra = 100',
  `apply_name` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_key2` (`apply_key`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='luu tat ca config';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configurations`
--

LOCK TABLES `configurations` WRITE;
/*!40000 ALTER TABLE `configurations` DISABLE KEYS */;
INSERT INTO `configurations` VALUES (4,'2017-01-03 13:34:24','2017-01-04 19:02:42',NULL,10,0,'registered_extra','0000','Số người đăng ký cộng thêm',0),(5,'2017-03-13 10:47:25','2017-03-13 10:54:38',NULL,1,0,'promo_key','D8T3','The Key to access Retail Mode App',0);
/*!40000 ALTER TABLE `configurations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devices` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `ip4` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT '0',
  `imei` varchar(255) DEFAULT NULL,
  `photo` varchar(1000) DEFAULT NULL,
  `video` varchar(1000) DEFAULT NULL,
  `fcm` tinyint(1) DEFAULT '0' COMMENT 'da push len firebase chua',
  `synced` tinyint(1) DEFAULT '0' COMMENT 'da dong bo xuong device chua',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_imei` (`imei`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES (1,'2017-03-13 11:07:26','2017-03-13 11:08:02',NULL,'Mobiistar PRIME X1','979278258845370','[\"http:\\/\\/retail.tools.mobiistar.com\\/api\\/cdn\\/metadata\\/huyen_my.jpg\"]','[\"http:\\/\\/retail.tools.mobiistar.com\\/api\\/cdn\\/metadata\\/huyen-my-cay-trang-tre-trung-7resize-ngoisao.vn.jpg\"]',1,0,0),(2,'2017-03-13 11:07:31','2017-03-13 11:08:02',NULL,'Mobiistar PRIME X1','979278258845371','[\"http:\\/\\/retail.tools.mobiistar.com\\/api\\/cdn\\/metadata\\/huyen_my.jpg\"]','[\"http:\\/\\/retail.tools.mobiistar.com\\/api\\/cdn\\/metadata\\/huyen-my-cay-trang-tre-trung-7resize-ngoisao.vn.jpg\"]',1,0,0),(3,'2017-03-13 11:07:34','2017-03-13 11:08:02',NULL,'Mobiistar PRIME X1','979278258845372','[\"http:\\/\\/retail.tools.mobiistar.com\\/api\\/cdn\\/metadata\\/huyen_my.jpg\"]','[\"http:\\/\\/retail.tools.mobiistar.com\\/api\\/cdn\\/metadata\\/huyen-my-cay-trang-tre-trung-7resize-ngoisao.vn.jpg\"]',1,0,0),(4,'2017-03-13 11:07:40',NULL,NULL,'Mobiistar PRIME X2','979278258845373','','',1,0,0),(5,'2017-03-13 11:07:44',NULL,NULL,'Mobiistar PRIME X2','979278258845374','','',1,0,0),(6,'2017-03-13 11:07:49','2017-03-13 13:44:14',NULL,'Mobiistar PRIME X3','979278258845375','','',1,0,0);
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mbs_groups`
--

DROP TABLE IF EXISTS `mbs_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mbs_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) DEFAULT '0' COMMENT '0: group lon nhat',
  `group_name` varchar(255) DEFAULT NULL,
  `permission` text,
  `menus_view` varchar(1000) DEFAULT NULL,
  `locked` tinyint(1) DEFAULT '0' COMMENT '1: nhom bi khoa',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `user_ip` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0' COMMENT '1: nhom bi xoa',
  `cnf_reports` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mbs_groups`
--

LOCK TABLES `mbs_groups` WRITE;
/*!40000 ALTER TABLE `mbs_groups` DISABLE KEYS */;
INSERT INTO `mbs_groups` VALUES (1,0,'Admin','{\"models\":{\"add\":1,\"delete\":1,\"view\":1,\"execute\":1},\"promotionsctrl\":{\"add\":1,\"edit\":1,\"delete\":1,\"view\":1,\"export\":1,\"execute\":1},\"profiles\":{\"edit\":1,\"execute\":1,\"view\":1},\"permissions\":{\"add\":1,\"edit\":1,\"view\":1,\"delete\":1},\"modules\":{\"add\":1,\"edit\":1,\"view\":1,\"delete\":1},\"menus\":{\"execute\":1,\"view\":1},\"groups\":{\"add\":1,\"edit\":1,\"execute\":1,\"view\":1,\"delete\":1},\"users\":{\"add\":1,\"edit\":1,\"execute\":1,\"view\":1,\"delete\":1},\"configurations\":{\"edit\":1,\"add\":1,\"execute\":1,\"view\":1,\"delete\":1}}','017,53,55,56,54,57,58,0,1,42,43,44,3,8,9,4,10,11,5,12,6,13,14,7,15,16,49',0,'2016-09-01 09:47:30','2016-09-06 17:17:11',11,'127.0.0.1','conglinh',0,'{\"tech4rums\":{\"phone\":{\"label\":\"Số điện thoại\", \"format\":\"string\", \"sort\":1}, \"status\":{\"label\":\"Trạng thái\", \"format\":\"string\", \"sort\":1}, \"modified\":{\"label\":\"Cập nhật\", \"format\":\"datetime\", \"sort\":1}}}'),(2,0,'Product','{\"profiles\":{\"edit\":1,\"execute\":1,\"view\":1},\"exchanges\":{\"view\":1,\"ProfitPerDay\":1,\"SoldDetail\":1,\"SoldPerDay\":1,\"YieldPerDate\":1,\"YieldPerModel\":1,\"YieldPerDay\":1}}','1,42,43,44,51,45,17',0,'2016-09-05 04:02:28','2016-09-05 10:48:37',11,'14.161.12.217',NULL,0,NULL),(3,0,'MKT','{\"distributors\":{\"add\":1,\"export\":1,\"import\":1,\"edit\":1,\"execute\":1,\"view\":1,\"delete\":1},\"campaigns\":{\"add\":1,\"export\":1,\"import\":1,\"edit\":1,\"execute\":1,\"view\":1,\"delete\":1},\"campaign_distributors\":{\"export\":1,\"import\":1,\"edit\":1,\"add\":1,\"view\":1,\"delete\":1},\"user_coupons\":{\"view\":1},\"exchanges\":{\"SoldDetail\":1,\"SoldPerDay\":1,\"ProfitPerDay\":1,\"YieldPerDate\":1,\"YieldPerModel\":1,\"view\":1,\"YieldPerDay\":1},\"campaign_gifts\":{\"export\":1,\"import\":1,\"edit\":1,\"add\":1,\"execute\":1,\"view\":1,\"delete\":1},\"precepts\":{\"add\":1,\"export\":1,\"import\":1,\"edit\":1,\"execute\":1,\"view\":1,\"delete\":1},\"social_users\":{\"view\":1},\"users_winner\":{\"export\":1,\"view\":1,\"execute\":1},\"complaints\":{\"export\":1,\"import\":1,\"edit\":1,\"add\":1,\"execute\":1,\"view\":1,\"delete\":1},\"profiles\":{\"edit\":1,\"execute\":1,\"view\":1},\"dashboard\":{\"export\":1,\"execute\":1,\"view\":1}}','31,33,2,34,32,36,37,35,45,47,17,51,23,18,24,29,30,25,26,27,50,52,43,42,1,44,46',0,'2016-09-01 09:12:36','2016-09-06 10:51:02',11,'113.161.74.223','conglinh',0,NULL),(4,0,'Sale','{\"exchanges\":{\"SoldDetail\":1,\"ProfitPerDay\":1,\"view\":1},\"users_winner\":{\"execute\":1},\"profiles\":{\"edit\":1,\"execute\":1,\"view\":1}}','51,45,17,25,50,43,42,1,44',0,'2016-09-01 16:35:13','2016-09-05 14:26:10',11,'14.161.12.217','conglinh',0,NULL),(5,0,'CC','{\"users_winner\":{\"export\":1,\"view\":1,\"execute\":1},\"complaints\":{\"export\":1,\"import\":1,\"edit\":1,\"add\":1,\"execute\":1,\"view\":1,\"delete\":1},\"profiles\":{\"edit\":1,\"execute\":1,\"view\":1}}','27,25,17,50,52,43,42,1,44',0,'2016-09-05 04:02:15','2016-09-05 14:26:00',11,'14.161.12.217',NULL,0,NULL),(6,0,'Kế Toán','{\"exchanges\":{\"SoldDetail\":1,\"ProfitPerDay\":1,\"view\":1},\"profiles\":{\"edit\":1,\"execute\":1,\"view\":1}}','51,45,17,1,42,43,44',0,'2017-02-08 10:56:18','2017-02-08 10:56:18',11,'14.161.12.217',NULL,0,NULL);
/*!40000 ALTER TABLE `mbs_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mbs_menus`
--

DROP TABLE IF EXISTS `mbs_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mbs_menus` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) DEFAULT '0',
  `menu_name` varchar(255) DEFAULT NULL,
  `menu_type` int(11) DEFAULT NULL COMMENT '1: chuc nang, 2: he thong',
  `module` varchar(255) DEFAULT NULL COMMENT 'vi du compaigns module',
  `functions` varchar(500) DEFAULT NULL,
  `router` varchar(255) DEFAULT NULL COMMENT 'module+router=url',
  `icon` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT '1',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '1: module bi xoa',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mbs_menus`
--

LOCK TABLES `mbs_menus` WRITE;
/*!40000 ALTER TABLE `mbs_menus` DISABLE KEYS */;
INSERT INTO `mbs_menus` VALUES (1,0,'Hệ thống',NULL,'','','','',20,0),(2,0,'Sự kiện',NULL,'','','','',1,1),(3,1,'Quyền',NULL,'','','','fa-user-secret',27,0),(4,1,'Nhóm chức năng',NULL,'','','','fa-cogs',33,0),(5,1,'Danh mục',NULL,'','','','fa-barcode',39,0),(6,1,'Nhóm người dùng',NULL,'','','','fa-users',43,0),(7,1,'Người dùng',NULL,'','','','fa-user',50,0),(8,3,'Thêm mới',NULL,'permissions','{\"add\":\"Thêm\"}','add','',28,0),(9,3,'Danh sách',NULL,'permissions','{\"edit\":\"Sửa\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','',29,0),(10,4,'Thêm mới',NULL,'modules','{\"add\":\"Thêm\"}','add','',34,0),(11,4,'Danh sách',NULL,'modules','{\"edit\":\"Sửa\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','',35,0),(12,5,'Cấu hình',NULL,'menus','{\"execute\":\"Thực hiện\",\"view\":\"Xem\"}','view','',40,0),(13,6,'Thêm mới',NULL,'groups','{\"add\":\"Thêm\"}','add','',44,0),(14,6,'Danh sách',NULL,'groups','{\"edit\":\"Sửa\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','',45,0),(15,7,'Thêm mới',NULL,'users','{\"add\":\"Thêm\"}','add','',51,0),(16,7,'Danh sách',NULL,'users','{\"edit\":\"Sửa\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','',52,0),(17,0,'Chức năng',NULL,'','','','',1,0),(18,17,'Quà tặng',NULL,'','','','fa-gift',50,1),(19,18,'Quà hằng ngày',NULL,'','','','fa-briefcase',32,1),(20,18,'Vouchers',NULL,'','','','',39,1),(21,18,'Thẻ cào',NULL,'','','','',40,1),(22,19,'Thêm mới',NULL,'campaign_gifts','{\"add\":\"Thêm\"}','add','',33,1),(23,18,'Quà hằng ngày ',NULL,'campaign_gifts','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','',51,1),(24,17,'Châm ngôn',NULL,'','','','fa-chrome',66,1),(25,17,'Người chơi',NULL,'','','','fa-odnoklassniki',75,1),(26,25,'Tất cả',NULL,'social_users','{\"view\":\"Xem\"}','view','',76,1),(27,25,'May mắn',NULL,'users_winner','{\"export\":\"Export\",\"view\":\"Xem\"}','view','',77,1),(28,25,'Spam',NULL,'blacklist','{\"export\":\"Export\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','',80,1),(29,24,'Thêm mới',NULL,'precepts','{\"add\":\"Thêm\"}','add','',67,1),(30,24,'Danh sách',NULL,'precepts','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','',68,1),(31,2,'Đại lý',NULL,'','','','fa-users',2,1),(32,2,'Sự kiện',NULL,'','','','fa-diamond',11,1),(33,31,'Thêm mới',NULL,'distributors','{\"add\":\"Thêm\"}','add','',3,1),(34,31,'Danh sách',NULL,'distributors','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','',4,1),(35,32,'Gán đại lý',NULL,'campaign_distributors','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','',20,1),(36,32,'Thêm mới',NULL,'campaigns','{\"add\":\"Thêm\"}','add','',12,1),(37,32,'Danh sách',NULL,'campaigns','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','',13,1),(38,32,'Gán đại lý',NULL,'campaign_distributors','{\"add\":\"Thêm\"}','add','',27,1),(39,18,'Mã giảm giá',NULL,'gift_vouchers','{\"export\":\"Export\",\"import\":\"Import\",\"view\":\"Xem\"}','view','',59,1),(40,18,'Thẻ cào',NULL,'gift_cards','{\"export\":\"Export\",\"view\":\"Xem\"}','view','',63,1),(41,7,'Đăng xuất',NULL,'users','{\"execute\":\"Thực hiện\"}','sign_out','',92,1),(42,1,'Cá nhân',NULL,'','','','fa-user',21,0),(43,42,'Hồ sơ',NULL,'profiles','{\"edit\":\"Sửa\",\"execute\":\"Thực hiện\",\"view\":\"Xem\"}','view','',22,0),(44,42,'Đăng xuất',NULL,'profiles','{\"execute\":\"Thực hiện\"}','logout','',26,0),(45,17,'Biểu đồ',NULL,'','','','fa-pie-chart',36,1),(46,45,'Mini game',NULL,'dashboard','{\"export\":\"Export\",\"execute\":\"Thực hiện\",\"view\":\"Xem\"}','view','fa-dashboard',37,1),(47,45,'Voucher',NULL,'user_coupons','{\"view\":\"Xem\"}','chart_view','',41,1),(48,2,'Model',NULL,'modem_phones','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','fa-building',27,1),(49,1,'Cài đặt',NULL,'configurations','{\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','fa-cog',57,0),(50,25,'Đổi máy',NULL,'users_winner','{\"execute\":\"Thực hiện\"}','exchange','',86,1),(51,45,'Đổi máy',NULL,'exchanges','{\"SoldDetail\":\"Bán chi tiết\",\"SoldPerDay\":\"Bán theo ngày\",\"ProfitPerDay\":\"LN theo ngày\",\"YieldPerDate\":\"TK theo ngày\",\"YieldPerModel\":\"TK theo SP\",\"view\":\"Xem\",\"YieldPerDay\":\"ĐK theo ngày\"}','view','fa-television',42,1),(52,25,'Khiếu nại',NULL,'complaints','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}','view','fa-odnoklassniki',87,1),(53,17,'Model',NULL,'','','','',2,0),(54,17,'Promo',NULL,'','','','',11,0),(55,53,'Thêm',NULL,'models','{\"add\":\"Thêm\"}','add','',3,0),(56,53,'Danh sách',NULL,'models','{\"delete\":\"Xóa\",\"view\":\"Xem\",\"execute\":\"Thực hiện\"}','view','',4,0),(57,54,'Thêm',NULL,'promotionsctrl','{\"add\":\"Thêm\"}','add','',12,0),(58,54,'Danh sách',NULL,'promotionsctrl','{\"edit\":\"Sửa\",\"delete\":\"Xóa\",\"view\":\"Xem\",\"export\":\"Export\",\"execute\":\"Thực hiện\"}','view','',13,0);
/*!40000 ALTER TABLE `mbs_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mbs_modules`
--

DROP TABLE IF EXISTS `mbs_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mbs_modules` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(255) DEFAULT NULL,
  `module_key` varchar(255) NOT NULL DEFAULT '' COMMENT 'class name',
  `functions` varchar(1000) DEFAULT NULL COMMENT '{"add":"Thêm", "edit":"Sửa", "delete":"Xóa", "view":"Danh sách", "import":"Nhập file", "export":"Xuất file"}',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '1: module bi xoa',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `user_ip` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`module_key`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mbs_modules`
--

LOCK TABLES `mbs_modules` WRITE;
/*!40000 ALTER TABLE `mbs_modules` DISABLE KEYS */;
INSERT INTO `mbs_modules` VALUES (23,NULL,'admins','{\"view\":\"Xem\"}',1,NULL,NULL,NULL,NULL,NULL),(25,NULL,'blacklist','{\"export\":\"Export\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',1,NULL,NULL,NULL,NULL,NULL),(19,NULL,'campaigns','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',1,NULL,NULL,NULL,NULL,NULL),(21,NULL,'campaign_distributors','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',1,NULL,NULL,NULL,NULL,NULL),(15,NULL,'campaign_gifts','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',1,NULL,NULL,NULL,NULL,NULL),(30,NULL,'complaints','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',1,NULL,NULL,NULL,NULL,NULL),(27,NULL,'configurations','{\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',0,NULL,NULL,NULL,NULL,NULL),(29,NULL,'dashboard','{\"export\":\"Export\",\"execute\":\"Thực hiện\",\"view\":\"Xem\"}',0,NULL,NULL,NULL,NULL,NULL),(20,NULL,'distributors','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',1,NULL,NULL,NULL,NULL,NULL),(31,NULL,'exchanges','{\"SoldDetail\":\"Bán chi tiết\",\"SoldPerDay\":\"Bán theo ngày\",\"ProfitPerDay\":\"LN theo ngày\",\"YieldPerDate\":\"TK theo ngày\",\"YieldPerModel\":\"TK theo SP\",\"view\":\"Xem\",\"YieldPerDay\":\"ĐK theo ngày\"}',1,NULL,NULL,NULL,NULL,NULL),(13,NULL,'gift_cards','{\"export\":\"Export\",\"view\":\"Xem\"}',1,NULL,NULL,NULL,NULL,NULL),(14,NULL,'gift_vouchers','{\"export\":\"Export\",\"import\":\"Import\",\"view\":\"Xem\"}',1,NULL,NULL,NULL,NULL,NULL),(8,NULL,'groups','{\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',0,NULL,NULL,NULL,NULL,NULL),(7,NULL,'menus','{\"execute\":\"Thực hiện\",\"view\":\"Xem\"}',0,NULL,NULL,NULL,NULL,NULL),(34,NULL,'models','{\"add\":\"Thêm\",\"edit\":\"Sửa\",\"delete\":\"Xóa\",\"view\":\"Xem\",\"import\":\"Import\",\"export\":\"Export\",\"execute\":\"Thực hiện\"}',0,NULL,NULL,NULL,NULL,NULL),(26,NULL,'modem_phones','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',1,NULL,NULL,NULL,NULL,NULL),(6,NULL,'modules','{\"edit\":\"Sửa\",\"add\":\"Thêm\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',0,NULL,NULL,NULL,NULL,NULL),(5,NULL,'permissions','{\"edit\":\"Sửa\",\"add\":\"Thêm\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',0,NULL,NULL,NULL,NULL,NULL),(12,NULL,'precepts','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',1,NULL,NULL,NULL,NULL,NULL),(33,NULL,'profiles','{\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',0,NULL,NULL,NULL,NULL,NULL),(35,NULL,'promotionsctrl','{\"add\":\"Thêm\",\"edit\":\"Sửa\",\"delete\":\"Xóa\",\"view\":\"Xem\",\"import\":\"Import\",\"export\":\"Export\",\"execute\":\"Thực hiện\"}',0,NULL,NULL,NULL,NULL,NULL),(11,NULL,'social_users','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',1,NULL,NULL,NULL,NULL,NULL),(4,NULL,'users','{\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',0,NULL,NULL,NULL,NULL,NULL),(16,NULL,'users_winner','{\"export\":\"Export\",\"import\":\"Import\",\"edit\":\"Sửa\",\"add\":\"Thêm\",\"execute\":\"Thực hiện\",\"view\":\"Xem\",\"delete\":\"Xóa\"}',1,NULL,NULL,NULL,NULL,NULL),(22,NULL,'user_coupons','{\"view\":\"Xem\"}',1,NULL,NULL,NULL,NULL,NULL),(1,NULL,'versions','{\"export\":\"Export\",\"import\":\"Import\"}',1,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `mbs_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mbs_permissions`
--

DROP TABLE IF EXISTS `mbs_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mbs_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(255) DEFAULT NULL,
  `permission_key` varchar(255) DEFAULT NULL COMMENT 'add, edit, ...',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '1: module bi xoa',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `user_ip` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_key_UNIQUE` (`permission_key`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mbs_permissions`
--

LOCK TABLES `mbs_permissions` WRITE;
/*!40000 ALTER TABLE `mbs_permissions` DISABLE KEYS */;
INSERT INTO `mbs_permissions` VALUES (7,'Thêm','add',0,NULL,NULL,NULL,NULL,NULL),(8,'Sửa','edit',0,NULL,NULL,NULL,NULL,NULL),(9,'Xóa','delete',0,NULL,NULL,NULL,NULL,NULL),(10,'Xem','view',0,NULL,NULL,NULL,NULL,NULL),(11,'Import','import',0,NULL,NULL,NULL,NULL,NULL),(12,'Export','export',0,NULL,NULL,NULL,NULL,NULL),(13,'Thực hiện','execute',0,NULL,NULL,NULL,NULL,NULL),(14,'you2','hate',1,NULL,NULL,NULL,NULL,NULL),(15,'TK theo ngày','YieldPerDate',0,NULL,NULL,NULL,NULL,NULL),(16,'TK theo SP','YieldPerModel',0,NULL,NULL,NULL,NULL,NULL),(18,'ĐK theo ngày','YieldPerDay',0,NULL,NULL,NULL,NULL,NULL),(19,'Bán theo ngày','SoldPerDay',0,NULL,NULL,NULL,NULL,NULL),(20,'Bán chi tiết','SoldDetail',0,NULL,NULL,NULL,NULL,NULL),(21,'LN theo ngày','ProfitPerDay',0,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `mbs_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metalogs`
--

DROP TABLE IF EXISTS `metalogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metalogs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `ip4` varchar(255) DEFAULT NULL,
  `imei` varchar(255) DEFAULT NULL,
  `file` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metalogs`
--

LOCK TABLES `metalogs` WRITE;
/*!40000 ALTER TABLE `metalogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `metalogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone_models`
--

DROP TABLE IF EXISTS `phone_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phone_models` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `ip4` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_model` (`model`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone_models`
--

LOCK TABLES `phone_models` WRITE;
/*!40000 ALTER TABLE `phone_models` DISABLE KEYS */;
INSERT INTO `phone_models` VALUES (1,'2017-03-13 11:07:26','2017-03-13 11:07:34',NULL,'Mobiistar PRIME X1',0),(4,'2017-03-13 11:07:40','2017-03-13 11:07:44',NULL,'Mobiistar PRIME X2',0),(6,'2017-03-13 11:07:49','2017-03-13 13:44:14',NULL,'Mobiistar PRIME X3',0);
/*!40000 ALTER TABLE `phone_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promotions`
--

DROP TABLE IF EXISTS `promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promotions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `ip4` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT '0',
  `photo` varchar(1000) DEFAULT NULL,
  `video` varchar(1000) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index2` (`model`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotions`
--

LOCK TABLES `promotions` WRITE;
/*!40000 ALTER TABLE `promotions` DISABLE KEYS */;
INSERT INTO `promotions` VALUES (1,'2017-03-13 11:08:02','2017-03-13 11:08:02',NULL,NULL,'Mobiistar PRIME X1','[\"http:\\/\\/retail.tools.mobiistar.com\\/api\\/cdn\\/metadata\\/huyen_my.jpg\"]','[\"http:\\/\\/retail.tools.mobiistar.com\\/api\\/cdn\\/metadata\\/huyen-my-cay-trang-tre-trung-7resize-ngoisao.vn.jpg\"]',0);
/*!40000 ALTER TABLE `promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `user_ip` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `module` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `level` tinyint(4) DEFAULT '0',
  `priority` tinyint(4) DEFAULT '0',
  `is_status` tinyint(4) DEFAULT '0',
  `status_log` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2195 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
INSERT INTO `system_logs` VALUES (2183,'2017-03-08 15:50:31','2017-03-08 15:50:31',11,'127.0.0.1','conglinh','users','sign_out','n/a',1,1,1,'n/a'),(2184,'2017-03-08 15:50:34','2017-03-08 15:50:34',11,'127.0.0.1','conglinh','users','sign_in','n/a',1,1,1,'n/a'),(2185,'2017-03-08 15:53:12','2017-03-08 15:53:12',11,'127.0.0.1','conglinh','users','sign_out','n/a',1,1,1,'n/a'),(2186,'2017-03-08 15:53:15','2017-03-08 15:53:15',11,'127.0.0.1','conglinh','users','sign_in','n/a',1,1,1,'n/a'),(2187,'2017-03-08 16:16:31','2017-03-08 16:16:31',11,'127.0.0.1','conglinh','users','sign_out','n/a',1,1,1,'n/a'),(2188,'2017-03-08 16:16:35','2017-03-08 16:16:35',11,'127.0.0.1','conglinh','users','sign_in','n/a',1,1,1,'n/a'),(2189,'2017-03-08 17:24:39','2017-03-08 17:24:39',11,'127.0.0.1','conglinh','users','sign_out','n/a',1,1,1,'n/a'),(2190,'2017-03-08 17:24:43','2017-03-08 17:24:43',11,'127.0.0.1','conglinh','users','sign_in','n/a',1,1,1,'n/a'),(2191,'2017-03-08 17:25:07','2017-03-08 17:25:07',11,'127.0.0.1','conglinh','users','sign_out','n/a',1,1,1,'n/a'),(2192,'2017-03-08 17:25:11','2017-03-08 17:25:11',11,'127.0.0.1','conglinh','users','sign_in','n/a',1,1,1,'n/a'),(2193,'2017-03-09 09:32:37','2017-03-09 09:32:37',11,'127.0.0.1','conglinh','users','sign_in','n/a',1,1,1,'n/a'),(2194,'2017-03-13 08:53:28','2017-03-13 08:53:28',11,'127.0.0.1','conglinh','users','sign_in','n/a',1,1,1,'n/a');
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `user_id` bigint(20) DEFAULT '0',
  `user_ip` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `group_id` bigint(20) DEFAULT '0',
  `password` varchar(255) DEFAULT NULL,
  `is_administrator` tinyint(1) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender_id` tinyint(1) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `is_status` tinyint(4) DEFAULT '0',
  `is_delete` tinyint(4) DEFAULT '0',
  `locked` tinyint(1) DEFAULT '0',
  `status_log` varchar(255) DEFAULT NULL,
  `permission` text,
  `menus_view` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'2015-11-30 05:39:09','2016-02-13 19:03:56',1,'::1','root',1,'ab6ba60ab0f6ae750f65859a3e8bcdff',1,'Bùi Huỳnh Kinh Luân',NULL,1,'0984206548','luanbhk@gmail.com','2016/02/13/726395a298b60cc202e13beb25e0c9aa.jpg',0,0,0,NULL,NULL,NULL),(2,'2015-11-30 05:39:09','2016-08-25 15:52:27',2,'14.161.12.217','admin',1,'6b9d69cfef9163f0257b2aa13577ba73',1,'Trọng Hóa',NULL,1,'0984206548','luanbhk@gmail.com','2016/07/27/692cf1bde8edae2a3a09638b6cbc0b34.jpg',0,0,0,NULL,NULL,NULL),(4,'2016-02-13 16:37:46','2016-02-13 16:37:46',2,'::1','kinhluan',1,'ab6ba60ab0f6ae750f65859a3e8bcdff',1,'Kinh Luân',NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL),(6,'2016-08-22 09:01:45','2016-08-22 09:01:45',3,'14.161.12.217','huynhtuananh',1,'c8813afd9f744be52f364984c4327609',0,'Huỳnh Tuấn Anh',NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL),(7,'2016-08-22 10:13:59','2017-02-06 14:08:35',7,'113.161.74.223','thuylinh',3,'94a6c69bcc83966b7b62851b2bdf9ce8',0,'Thùy Linh',NULL,NULL,NULL,NULL,'thuylinh.png',0,0,0,NULL,NULL,NULL),(8,'2016-08-25 15:53:06','2016-08-25 15:53:06',2,'14.161.12.217','hongnha.le',2,'ab6ba60ab0f6ae750f65859a3e8bcdff',0,'Hồng Nhã',NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL),(9,'2016-08-29 18:47:10','2016-12-20 14:10:23',9,'14.161.12.217','mkt_admin',3,'7a197848f144af307660f3e540e2d315',0,'MKT Admin',NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL),(11,'2016-08-30 08:18:20','2017-02-06 15:44:52',11,'14.161.12.217','conglinh',1,'5e570e982d6f1c096253f668d9a83f24',1,'Leon Tran','1993-09-19',NULL,'0961095661','conglinh.tran@mobiistar.vn','conglinh.jpg',0,0,0,NULL,NULL,NULL),(12,'2016-08-30 10:23:41','2017-01-05 10:46:52',12,'113.161.74.223','sale_mai.nguyen',4,'4a8efff8065a1d9a4c688aac22fe8f2b',0,'sale_mai.nguyen',NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL),(17,'2016-09-26 14:35:54','2016-09-26 14:35:54',2,'14.161.12.217','ad_kha',1,'b60ad21951b43a0ca1f24df03e86a79b',0,'Anh Kha',NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL),(18,'2016-09-26 14:40:25','2016-09-26 14:40:25',2,'14.161.12.217','carlngo',1,'b60ad21951b43a0ca1f24df03e86a79b',0,'carl ngo',NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL),(22,'2017-02-04 16:39:12','2017-02-06 15:41:38',22,'118.69.34.134','mbs_hotro',5,'e9ce4c7072f1ae53ca3be92ee163e54a',0,'Hỗ Trợ',NULL,NULL,NULL,NULL,'mbs_hotro.jpg',0,0,0,NULL,NULL,NULL),(23,'2017-02-08 10:55:06','2017-02-09 11:41:42',2,'14.161.12.219','mbs_kinhdoanh',4,'94201952e737dcf2fee2d2b5ceb3f5bd',0,'Kinh doanh MBS',NULL,NULL,NULL,NULL,'mbs_kinhdoanh.png',0,0,0,NULL,NULL,NULL),(24,'2017-02-08 10:55:32','2017-02-09 11:45:44',2,'14.161.12.219','mbs_ketoan',6,'b3e6441ff8856ecbf9a43ec6c213337f',0,'Kế Toán MBS',NULL,NULL,NULL,NULL,'mbs_ketoan.png',0,0,0,NULL,NULL,NULL),(25,'2017-02-09 11:47:41','2017-02-09 11:48:09',11,'14.161.12.217','mbs_product',2,'4dea6afaeec6d97af31d2a19462eae6e',0,'Phòng Product',NULL,NULL,NULL,NULL,'mbs_product.png',0,0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-14 15:40:28
