ALTER TABLE `winners` 
CHANGE COLUMN `source_branch` `source_branch` VARCHAR(255) NULL DEFAULT NULL COMMENT 'branch cua dien thoai dem doi' AFTER `type_at_shop`,
CHANGE COLUMN `source_name` `source_name` VARCHAR(255) NULL DEFAULT NULL COMMENT 'ten cua dien thoai dem doi' AFTER `source_branch`,
CHANGE COLUMN `source_price` `source_price` VARCHAR(255) NULL DEFAULT NULL COMMENT 'gia cua dien thoai dem doi' AFTER `source_name`,
CHANGE COLUMN `phone_on_site` `imei_on_site` VARCHAR(255) NULL DEFAULT '0' COMMENT 'imei dang ky tren site' ,
CHANGE COLUMN `phone_at_shop` `imei_at_shop` VARCHAR(255) NULL DEFAULT '0' COMMENT 'imei dem den shop de doi' ,
CHANGE COLUMN `phone_target` `imei_target` VARCHAR(255) NULL DEFAULT '0' COMMENT 'imei cua phone duoc doi' ;
