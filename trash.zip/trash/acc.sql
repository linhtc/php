
-- MySQL dump 10.13  Distrib 5.6.35, for Linux (x86_64)
--
-- Host: localhost    Database: primex2k17
-- ------------------------------------------------------
-- Server version	5.6.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `social_accounts`
--

DROP TABLE IF EXISTS `social_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_accounts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `social_type` int(11) DEFAULT NULL COMMENT 'fb:1, gplus:2, etc',
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `count` int(11) DEFAULT '0' COMMENT 'Dem so lan len fb',
  `total` bigint(20) DEFAULT '0' COMMENT 'Tong so users da check',
  `logged` tinyint(1) DEFAULT '0',
  `blocked` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0' COMMENT 'con dung duoc hay khong',
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_accounts`
--

LOCK TABLES `social_accounts` WRITE;
/*!40000 ALTER TABLE `social_accounts` DISABLE KEYS */;
INSERT INTO `social_accounts` VALUES (1,'2017-01-13 10:46:04','2017-01-18 04:23:04',1,'01237603564','Dth102061',47,731,1,0,0,'Đã mở khóa sau 2 giờ. Thời gian mở 2017-01-18 04:23:04'),(2,'2017-01-16 11:50:08','2017-01-17 10:32:40',1,'she.saigon2k@gmail.com','Dth102061',9,443,1,1,1,'RIP :(('),(3,'2017-01-16 14:44:51','2017-01-17 13:56:31',1,'she.saigon3k@gmail.com','Dth102061',13,243,1,1,1,'RIP :(('),(4,'2017-01-16 15:01:46','2017-01-17 13:57:24',1,'she.saigon4k@gmail.com','Dth102061',4,238,1,1,1,'RIP :(('),(5,'2017-01-16 15:15:51','2017-01-17 10:28:21',1,'she.saigon5k@gmail.com','Dth102061',32,300,1,1,1,'RIP :(('),(6,'2017-01-16 15:51:38','2017-01-17 10:32:15',1,'she.saigon6k@gmail.com','Dth102061',18,236,1,1,1,'RIP :(('),(7,'2017-01-16 17:30:05','2017-01-17 17:38:35',1,'she.saigon@yahoo.com','Dth102061',95,316,1,0,0,'Đã mở khóa sau 2 giờ. Thời gian mở 2017-01-17 17:38:35'),(8,'2017-01-16 17:38:52','2017-01-18 04:56:08',1,'she.saigon2k@yahoo.com','Dth102061',108,366,1,1,1,'RIP :(('),(9,'2017-01-16 17:46:30','2017-01-18 02:17:04',1,'she.saigon3k@yahoo.com','Dth102061',33,365,1,1,1,'RIP :(('),(10,'2017-01-16 17:48:48','2017-01-18 02:13:20',1,'she.saigon4k@yahoo.com','Dth102061',35,413,1,1,1,'RIP :(('),(11,'2017-01-16 17:55:10','2017-01-18 08:32:24',1,'she.saigon5k@yahoo.com','Dth102061',12,534,1,0,0,'Đã mở khóa sau 2 giờ. Thời gian mở 2017-01-18 08:32:24'),(12,'2017-01-16 17:59:26','2017-01-18 09:48:53',1,'she.saigon6k@yahoo.com','Dth102061',7,369,1,1,1,'RIP :(('),(13,'2017-01-17 14:21:55','2017-01-18 01:23:00',1,'leminhan.cst1@gmail.com','asus0987901163',70,189,1,0,0,'Đã mở khóa sau 2 giờ. Thời gian mở 2017-01-18 01:23:00'),(14,'2017-01-17 16:30:12','2017-01-17 16:30:23',1,'seeder1@mobiistar.vn','c0c0ny3utr4ntu4n',108,108,1,0,0,NULL),(15,'2017-01-18 08:10:01','2017-01-18 08:17:12',1,'01238898601','Dth102061',20,21,1,0,0,NULL);
/*!40000 ALTER TABLE `social_accounts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-19 11:08:07
