alter table winners
add column `campaign` bigint(20) DEFAULT '0' after `ip4`,
add column `distributor` bigint(20) DEFAULT '0' after `campaign`,
add column `phone_on_site` bigint(20) DEFAULT '0' COMMENT 'imei dang ky tren site',
add column `type_on_site` tinyint(1) DEFAULT '0' COMMENT '1 may mobiistar, 2 may hang khac',
add column `phone_at_shop` bigint(20) DEFAULT '0' COMMENT 'imei dem den shop de doi',
add column`type_at_shop` tinyint(1) DEFAULT '0' COMMENT '1 may mobiistar, 2 may hang khac',
add column `phone_target` bigint(20) DEFAULT '0' COMMENT 'imei cua phone duoc doi',
add column `voucher_code` varchar(255) DEFAULT NULL,
add column `voucher_value` varchar(255) DEFAULT NULL
;