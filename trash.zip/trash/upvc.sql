update gift_vouchers v 
set v.code_value = '50%'
where v.code_value = '1 tặng 1';

truncate test_vc;
insert into test_vc(id, `code`)
select v.id, v.code
from gift_vouchers v
where v.campaign = 12 and v.code_value = '50%' limit 9, 3;

update gift_vouchers v 
set v.apply_time = '20170523'
where v.id in (select p.id from test_vc p);