
update models m set m.rate = (
	select cast(sum(r.rate)/count(1) as decimal(12,1)) rate
	from rates r 
	where (r.brand, r.model) in ( (m.brand, m.model) )
)
where m.deleted = 0 and m.id > 0;