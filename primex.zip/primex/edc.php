<?php

$something = '1713290945665067';
$something = '1906143492948013';
$something = '117502638758342';

$encrypt = '653138316c5536466e577a334732253246624e7576373841253344253344'; // base_convert(encrypt($something), 16, 10);
$decrypt = decrypt($encrypt);

echo "\n<br />Greeting is: "; print_r($something); echo "\n<br />";
echo "\n<br />Encrypt is: "; print_r($encrypt); echo "\n<br />";
echo "\n<br />Decrypt is: "; print_r($decrypt); echo "\n<br />";

function encrypt($string, $key='tplus@!zKaC$3<!?'){
    return array_shift( unpack('H*', urlencode(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $string, MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_ECB), MCRYPT_RAND))))));
}

function decrypt($string, $key='tplus@!zKaC$3<!?'){
    return mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, base64_decode(urldecode(pack('H*', $string))), MCRYPT_MODE_ECB);
}

function bchexdec($hex)
{
    $dec = 0;
    $len = strlen($hex);
    for ($i = 1; $i <= $len; $i++) {
        $dec = bcadd($dec, bcmul(strval(hexdec($hex[$i - 1])), bcpow('16', strval($len - $i))));
    }
    return $dec;
}

?>